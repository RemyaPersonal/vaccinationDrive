﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Response
{
    public class ErrorList : List<Error>
    {
        public ErrorList()
        {
        }
    }
}
