﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Response
{
    public class ErrorType
    {
        public const string ERROR = "ERROR";

        public const string WARNING = "WARNING";

        public ErrorType()
        {
        }
    }
}
