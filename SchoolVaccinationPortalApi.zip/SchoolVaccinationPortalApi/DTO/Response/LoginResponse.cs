﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.Response
{
    public class LoginResponse
    {
        public string Status { get; set; }

        public string username { get; set; }
        public string Loginrole { get; set; }
    }
}
